# yolo > 2024-01-05 11:11pm
https://universe.roboflow.com/ncue-jcser/yolo-l2z3w

Provided by a Roboflow user
License: CC BY 4.0

